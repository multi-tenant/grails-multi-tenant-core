package tenant
import com.infusion.tenant.groovy.compiler.MultiTenant

/**
 * Maps domain name to tenantId
 */
@MultiTenant
class DomainTenantMap {

  String domainName
  Integer mappedTenantId

  static constraints = {}


}