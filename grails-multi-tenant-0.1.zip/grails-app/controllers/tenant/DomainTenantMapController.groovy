package tenant
/**
 * Default controller for managing the mapping of subdomains to tenantIds
 */
class DomainTenantMapController {
  def scaffold = DomainTenantMap

}