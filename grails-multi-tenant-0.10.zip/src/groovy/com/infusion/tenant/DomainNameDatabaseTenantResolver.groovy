package com.infusion.tenant;


import com.infusion.util.event.EventBroker
import com.infusion.util.event.groovy.GroovyEventBroker
import com.infusion.util.domain.event.HibernateEvent
import org.springframework.context.ApplicationContext
import org.springframework.context.ApplicationContextAware;

/**
 * Implementation that looks up tenantIds from a local table DomainTenantMap that stores domain name to tenantId mappings. 
 */
public class DomainNameDatabaseTenantResolver extends BaseDomainNameTenantResolver implements ApplicationContextAware {

  /**
   * Used for listening to save events for DomainTenantMap domain class
   */
  GroovyEventBroker eventBroker
  ApplicationContext applicationContext


  public DomainNameDatabaseTenantResolver() {
  }

  /**
   * The event broker listens for every time a record is saved, then calls a refresh on the
   * list of hosts.
   */
  public void setEventBroker(GroovyEventBroker eventBroker) {
    if (eventBroker != null) {
      eventBroker.subscribe("hibernate.${HibernateEvent.saveOrUpdate}.${DomainTenantMap.class.getSimpleName()}") {
        event, broker ->
        this.initialize();
      }
    }
  }

  public void initialize() {
    hosts.clear()
    //This will load all domain tenants, regardless of which tenant they're for
    def list = applicationContext.getBean("tenant.DomainTenantMap").findAll("from tenant.DomainTenantMap");
    list.each {map ->
      hosts.put(map.domainName, map.mappedTenantId)
    }
  }

}
