package com.infusion.tenant.datasource;

/**
 * Created by IntelliJ IDEA.
 * User: eric
 * Date: Sep 25, 2009
 * Time: 9:42:50 PM
 * To change this template use File | Settings | File Templates.
 */
public enum Status {
    NotLoaded, Loading, Loaded
}
